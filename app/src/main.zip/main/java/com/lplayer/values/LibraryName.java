package com.lplayer.values;

/**
 * Created by irly on 05.12.2017.
 */

public enum LibraryName{
    TRACKS, ALBUMS, ARTISTS, GENRES, PLAYLISTS;
}

